package chatserver;

import model.User;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class NetworkConnect {//服务器端连接
    public static void main(String[] args) {
        ServerSocket ss;
        try {
            ss=new ServerSocket(3456);
            System.out.println("服务器启动,监听3456端口...");
            Socket s=ss.accept();//等待客户端连接，程序阻塞
            System.out.println("建立连接成功"+s);
            InputStream is=s.getInputStream();
            ObjectInputStream ois=new ObjectInputStream(is);
            User user=(User)ois.readObject();//转换成User对象
            System.out.println("用户名："+user.getUsername());
            System.out.println("密码："+user.getPassword());


        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
