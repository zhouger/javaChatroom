package chatserver;


import control.chatServer;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartServer extends JFrame implements ActionListener {
    JButton startServerJButton;
    JButton stopServerJButton;
    JPanel jPanel;

    public StartServer() {
        startServerJButton=new JButton("启动服务器");
        startServerJButton.addActionListener(this);
        stopServerJButton=new JButton("停止服务器");
        jPanel=new JPanel();
        jPanel.add(startServerJButton);
        jPanel.add(stopServerJButton);
        this.add(jPanel);


        this.setSize(400,300);
        this.setLocationRelativeTo(null);//窗口初始位置
        this.setVisible(true);//可调整
        this.setIconImage(new ImageIcon("picture/joker.png").getImage());//修改左上图标
        this.setTitle("服务器启动之");

    }

    public static void main(String[] args) {


        StartServer startServer=new StartServer();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==startServerJButton)
        {
            new chatServer();
        }


    }
}
