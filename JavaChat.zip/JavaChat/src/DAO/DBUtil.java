package DAO;

import java.sql.*;
import java.util.Date;


//数据库工具类
//封装方法
public class DBUtil {

    public static final String URL="jdbc:mysql://localhost:3306/chatdata?useUnicode=true&useSSL=false&characterEncoding=utf8";
    public static final String USERNAME="root";
    public static final String PASSWORD="032611";
        public static Connection getConnection()//连接数据库
        {
            Connection conn=null;

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn= DriverManager.getConnection(URL,USERNAME,PASSWORD);
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
            return conn;
        }


        //保存邮件信息方法
        public  static void saveEamil(String receiver_mail,String MailTitle,String MailMessage)
        {
            Connection conn=getConnection();
            String Email_Message_sql="insert into email_message(receiver_mail,MailTitle,MailMessage,sendtime) values(?,?,?,?)";
            PreparedStatement ptmt;
            try{
                ptmt=conn.prepareStatement(Email_Message_sql);
                ptmt.setString(1,receiver_mail);
                ptmt.setString(2,MailTitle);
                ptmt.setString(3,MailMessage);

                Date date=new Date();
                ptmt.setTimestamp(4,new java.sql.Timestamp(date.getTime()));
                ptmt.executeUpdate();
                closeDB(conn,ptmt);

            }catch (SQLException e)
            {
                e.printStackTrace();
            }

        }

        //保存聊天信息方法
        public static void saveMessage(String sender,String receiver,String content)
        {

            Connection conn=getConnection();
            String Inster_Into_Message_sql="insert into message(sender,receiver,content,sendtime) values(?,?,?,?)";
            PreparedStatement ptmt;
            try {
                ptmt=conn.prepareStatement(Inster_Into_Message_sql);
                ptmt.setString(1,sender);
                ptmt.setString(2,receiver);
                ptmt.setString(3,content);
                //时间返回
                Date date=new Date();
                ptmt.setTimestamp(4,new java.sql.Timestamp(date.getTime()));
                ptmt.executeUpdate();
                closeDB(conn,ptmt);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }





    public static void insertIntoUserRelation(String masteruser,String slaveuser,String relaationtype)
    {
        Connection conn=getConnection();
        String Inster_Into_UserRelation_sql="insert into userrelation(masteruser,slaveuser,relationtype) values(?,?,?)";
        PreparedStatement ptmt;
        try {
            ptmt=conn.prepareStatement(Inster_Into_UserRelation_sql);
            ptmt.setString(1,masteruser);
            ptmt.setString(2,slaveuser);
            ptmt.setString(3,relaationtype);
            ptmt.executeUpdate();
            closeDB(conn,ptmt);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }








    public static boolean seekUserRelation(String masterUser,String slaveUser,String relationType)
    {
        boolean friendRelation=false;
        String seek_User_Relation_Sql="select *from userrelation where masteruser=? and slaveuser=? and relationtype=?";
        Connection conn= getConnection();
        PreparedStatement ptmt;
        try {
            ptmt = conn.prepareStatement(seek_User_Relation_Sql);
            ptmt.setString(1,masterUser);//第一个问号
            ptmt.setString(2,slaveUser);//第一个问号
            ptmt.setString(3,relationType);//第一个问号
            ResultSet rs=ptmt.executeQuery();//返回结果集(好友列表)
            friendRelation= rs.next();
            closeDB(conn,ptmt,rs);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }



        public static boolean seekUser(String userName)
        {
            boolean seekSuccess=false;
            Connection conn=getConnection();
            String seek_User_Sql="select *from user where username=?";
            PreparedStatement ptmt;
            try {
                ptmt=conn.prepareStatement(seek_User_Sql);
                ptmt.setString(1,userName);
                ResultSet rs=ptmt.executeQuery();
                seekSuccess=rs.next();
                closeDB(conn,ptmt,rs);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            return  seekSuccess;
        }

        public static void instertIntoUser(String userName,String password)
        {
            Connection conn=getConnection();
            String seek_User_Sql="insert into user(username,password) values(?,?)";
            PreparedStatement ptmt;
            try {
                ptmt=conn.prepareStatement(seek_User_Sql);
                ptmt.setString(1,userName);
                ptmt.setString(2,password);
                ptmt.executeUpdate();
                closeDB(conn,ptmt);
            } catch (SQLException e) {
                e.printStackTrace();
            }


        }



        //获得好友列表方法
    public static String seekAllFriend(String userName)
    {
        String allFriend="";
        String seek_All_Friend_Sql="select slaveuser from userrelation where masteruser=? and relationtype='1'";
        Connection conn= getConnection();
        PreparedStatement ptmt;
        try {
            ptmt = conn.prepareStatement(seek_All_Friend_Sql);
            ptmt.setString(1,userName);//第一个问号
            ResultSet rs=ptmt.executeQuery();//返回结果集(好友列表)
            while (rs.next())

                allFriend+=" "+rs.getString(1);
                closeDB(conn,ptmt,rs);


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allFriend;
    }




        //登录验证方法

    public static boolean loginValidate(String userName,String password){
            boolean loginSuccess=false;
            Connection conn= getConnection();
            String user_Login_Sql="select *from user where username=? and password=?";
            PreparedStatement ptmt= null;
        try {
            ptmt = conn.prepareStatement(user_Login_Sql);
            ptmt.setString(1,userName);
            ptmt.setString(2,password);
            ptmt.executeQuery();
            ResultSet rs=ptmt.executeQuery();//返回结果集
            loginSuccess =rs.next();
            closeDB(conn,ptmt,rs);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return loginSuccess;
    }


    public static void closeDB(Connection conn,PreparedStatement ptmt)
    {
        if(conn!=null)
        {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        if(ptmt!=null)
        {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
    //关闭资源
    public static void closeDB(Connection conn,PreparedStatement ptmt,ResultSet rs)
    {
        if(conn!=null)
        {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        if(ptmt!=null)
        {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }



        if(rs!=null)
        {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

    }

}
