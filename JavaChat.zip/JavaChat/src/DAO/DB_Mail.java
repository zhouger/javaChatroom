package DAO;
import com.sun.mail.util.MailSSLSocketFactory;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import static DAO.DBUtil.saveEamil;



public class DB_Mail extends Thread {
    private String mailAdr;//邮箱
    private String content;//邮件的内容
    private String subject;//邮件的题目
    public DB_Mail(String mailAdr, String subject, String content) {
        super();
        this.mailAdr = mailAdr;
        this.subject = subject;
        this.content = content;
    }
    @Override
    public void run() {
        super.run();
        try {
            sendMail(mailAdr, subject, content);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void sendMail(String mailAdr, String subject, String content) throws Exception {
        //加密的邮件套接字协议工厂
        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);
        final Properties props = new Properties();

        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.qq.com");
        // smtp登陆的账号、密码 ；需开启smtp登陆
        props.setProperty("mail.debug", "true");
        props.put("mail.user", "2112581537@qq.com");
        props.put("mail.password", "rryebipokrqfcjei");
        // 特别需要注意，要将ssl协议设置为true,否则会报530错误
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.ssl.socketFactory", sf);
        Authenticator authenticator = new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {

                String userName = props.getProperty("mail.user");
                String password = props.getProperty("mail.password");
                return new PasswordAuthentication(userName, password);
            }
        };
        // 使用环境属性和授权信息，创建邮件会话
        Session mailSession = Session.getInstance(props, authenticator);
        // 邮件消息对线
        MimeMessage message = new MimeMessage(mailSession);
        // 设置发件人
        try {
            InternetAddress form = new InternetAddress(props.getProperty("mail.user"));
            message.setFrom(form);
            // 收件人
            InternetAddress to = new InternetAddress(mailAdr);
            message.setRecipient(Message.RecipientType.TO, to);
            // 邮件标题
            message.setSubject(subject);
            // 邮件的内容体
            message.setContent(content, "text/html;charset=UTF-8");

            // 发送邮件
            Transport.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public DB_Mail(String text)
    {
        JFrame jf = new JFrame(text);
        jf.setSize(500, 500);
        jf.setLocationRelativeTo(null);
        ImageIcon bg=new ImageIcon("picture/background.png");
        JPanel panel = new JPanel(null);


        JLabel jLabel=new JLabel(bg);//获得背景
        jLabel.setLocation(200,320);
        jLabel.setSize(250,130);

        JLabel jla1 = new JLabel("收件邮箱: ");
        jla1.setLocation(50,50);
        jla1.setSize(100, 50);
        jla1.setFont(new Font("123", 5, 20));

        JTextField textField = new JTextField(8);
        textField.setFont(new Font("mailAdr", Font.PLAIN, 20));
        textField.setLocation(150,50);
        textField.setSize(250, 50);

        JLabel jla2 = new JLabel("邮件标题: ");
        jla2.setLocation(50,150);
        jla2.setSize(100, 50);
        jla2.setFont(new Font("123", 5, 20));

        JTextField textField1 = new JTextField(8);//
        textField1.setFont(new Font("subject", Font.PLAIN, 20));
        textField1.setLocation(150,150);
        textField1.setSize(250, 50);

        JLabel jla3 = new JLabel("邮件内容: ");
        jla3.setLocation(50,250);
        jla3.setSize(100, 50);
        jla3.setFont(new Font("123", 5, 20));

        JTextField textField3 = new JTextField(8);//
        textField3.setFont(new Font("content", Font.PLAIN, 20));
        textField3.setLocation(150,250);
        textField3.setSize(250, 50);

        JButton btn = new JButton(new ImageIcon("picture/mail.png"));
        btn.setLocation(50,350);
        btn.setSize(100, 50);

        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DB_Mail d = new DB_Mail(textField.getText(), textField1.getText(),textField3.getText());
                d.start();
                saveEamil( textField.getText(),textField1.getText(), textField3.getText());
            }
        });

        panel.add(jLabel);
        panel.add(jla1);
        panel.add(jla2);
        panel.add(jla3);
        panel.add(textField);
        panel.add(textField1);
        panel.add(textField3);
        panel.add(btn);

        jf.setContentPane(panel);
        jf.setVisible(true);
    }
}

