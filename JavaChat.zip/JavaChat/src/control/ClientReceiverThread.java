package control;

import model.Message;
import model.MessageType;
import view.ClientLogin;
import view.FriendChat;
import view.FriendList;

import javax.swing.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class ClientReceiverThread extends Thread{
    //创建客户端接收者线程
    Socket s;
    public ClientReceiverThread(Socket s)//创建构造方法
    {
        this.s=s;
    }

    public void run()
    {
        ObjectInputStream ois;
        try {

            while (true)
            {
                ois = new ObjectInputStream(s.getInputStream());
                Message mess=(Message)ois.readObject();//读信息转类型
                String sender=mess.getSender();
                String receiver=mess.getReceiver();

                //判断添加好友是否成功
                if(mess.getMessageType().equals(Message.ADD_NEW_FRIEND_FAILURE_NO_USER))
                {
                    JOptionPane.showMessageDialog(null,"该用户不存在，添加好友失败!");
                }


                if(mess.getMessageType().equals(Message.ADD_NEW_FRIEND_FAILURE_ALREADY_FRIEND))
                {
                    JOptionPane.showMessageDialog(null,"已经有该好友!不能重复添加");
                }

                if(mess.getMessageType().equals(Message.ADD_NEW_FRIEND_SUCCESS))
                {
                    JOptionPane.showMessageDialog(null,"添加好友成功");
                    //更新好友列表
                    FriendList friendList=(FriendList) ClientLogin.hmFriendList.get(sender);
                    String allFriend= mess.getChatContent();
                    friendList.updataFriendList(allFriend);

                }

                //接收上线好友名字
                if(mess.getMessageType().equals(Message.NEW_ONLINE_FRIEND))
                {
                    System.out.println(sender+"上线了，准备激活图标");
                    //激活sender图标  得到FriendList里面的receiver激活sender图标
                    FriendList friendList=(FriendList)ClientLogin.hmFriendList.get(receiver);
                    friendList.setEnabledNewOnLineFriendIcno(sender);

                }

                if(mess.getMessageType().equals(MessageType.RESPON_ONLINE_FRIEND))
                {
                    System.out.println(sender+"在线好友的名字："+mess.getOnLineFriend());
                    FriendList friendList=(FriendList)ClientLogin.hmFriendList.get(sender);

                    //取得发送者好友对象
                    friendList.setEnabledOnLineFriendIcno(mess.getOnLineFriend());



                }



                if(mess.getMessageType().equals(Message.COMMON_CHAR_MESSAGE))
                {
                    System.out.println(mess.getSender()+"对"+mess.getReceiver()+"说:"+mess.getChatContent());
                    //打印信息
                    //接受方好友聊天界面显示服务器转发的聊天信息

                    //receiver=mess.getReceiver();
                    FriendChat friendChat=(FriendChat) FriendList.hmFriendChat.get(receiver+"to"+sender);

                    //把mess 再 friendChat上显示处理

                        friendChat.append(mess);


                }

                //表情信息
                if(mess.getMessageType().equals(Message.PICTURE_CHAR_MESSAGE))
                {

                    System.out.println("用户发送了一个表情"+mess.getMes());
                }



            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
