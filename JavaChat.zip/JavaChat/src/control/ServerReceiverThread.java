package control;

import DAO.DBUtil;
import model.Message;
import model.MessageType;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Iterator;
import java.util.Set;

public class ServerReceiverThread extends Thread{

    Socket s;
    public ServerReceiverThread(Socket s)
    {
    this.s=s;
    }

        public void run()//接受客户端对象Message(mess)
        {
            ObjectInputStream ois;
            try {
                while(true){
                    //接收多次聊天信息
                    ois=new ObjectInputStream(s.getInputStream());
                    Message mess=(Message)ois.readObject();//读信息转类型
                    String sender=mess.getSender();


                    //在服务器端添加新好友消息，并判断能不能添加为好友
                    if(mess.getMessageType().equals(Message.ADD_NEW_FRIEND))
                    {

                       String newFriendName= mess.getChatContent();
                        System.out.println("新好友名字:"+newFriendName);
                        if(DBUtil.seekUser(newFriendName))
                        {
                            if(DBUtil.seekUserRelation(sender,newFriendName,"1"))
                            {//已有好友
                                mess.setMessageType(Message.ADD_NEW_FRIEND_FAILURE_ALREADY_FRIEND);
                            }else {
                                //可以添加
                                DBUtil.insertIntoUserRelation(sender,newFriendName,"1");
                                String allFriend=DBUtil.seekAllFriend(sender);
                                mess.setChatContent(allFriend);
                                mess.setMessageType(MessageType.ADD_NEW_FRIEND_SUCCESS);
                            }
                        }else
                        {
                            mess.setMessageType(Message.ADD_NEW_FRIEND_FAILURE_NO_USER);
                        }
                        //发送消息到客户端进行处理
                        sendMessage(s,mess);
                    }





                    //服务器接受到请求激活图标,获得全部在线好友
                    if(mess.getMessageType().equals(Message.NEW_ONLINE_FRIEND_TO_SERVER))
                    {
                        System.out.println(sender+"上线了");
                        //拿到好友名字
                        Set onLineFriendSet= chatServer.hmSocket.keySet();
                        Iterator it=onLineFriendSet.iterator();//迭代器对象
                        while(it.hasNext())//循环遍历取出名字
                        {
                            String friendName=(String)it.next();
                            //给除自己以外的人发送上线激活消息

                            if(!(friendName.equals(sender)))
                            {
                                Socket receiverSocket=(Socket) chatServer.hmSocket.get(friendName);
                                //向在线好友发送消息
                                mess.setReceiver(friendName);//去名字
                                mess.setMessageType(Message.NEW_ONLINE_FRIEND);
                                //sendMessage(receiverSocket,mess);//给在线好友发送消息
                            }


                        }
                    }


                    //服务器收到请求信息,并输出
                    if(mess.getMessageType().equals(Message.REQUEST_ONLINE_FRIEND))
                    {
                        System.out.println("服务器收到了"+sender+"发送的请求");
                        //拿到在线好友的名字
                        Set onLineFriendSet= chatServer.hmSocket.keySet();
                        Iterator it=onLineFriendSet.iterator();//迭代器对象
                        String onLineFriend="";
                        while(it.hasNext())//循环遍历取出名字
                        {
                            String friendName=(String)it.next();
                            if(!(friendName.equals(sender)))  onLineFriend=""+friendName+onLineFriend;
                        }
                        System.out.println(sender+"在线好友有："+onLineFriend);
                        //在线好友名字发送到客户端
                        mess.setOnLineFriend(onLineFriend);//读取在线好友名字
                        mess.setMessageType(MessageType.RESPON_ONLINE_FRIEND);//判断消息类型
                        ObjectOutputStream oos=new ObjectOutputStream(s.getOutputStream());
                        oos.writeObject(mess);//发送回客户端

                    }


                    if(mess.getMessageType().equals(Message.PICTURE_CHAR_MESSAGE))
                    {
                        String emoNum=mess.getMes();
                        System.out.println("用户发送了一个表情"+emoNum+"(服务端转发)");
                        mess.setMessageType(Message.PICTURE_CHAR_MESSAGE);
                        //转发到客户端
                        ObjectOutputStream oos=new ObjectOutputStream(s.getOutputStream());
                        oos.writeObject(mess);//发送回客户端
                    }




                    if(mess.getMessageType().equals(Message.COMMON_CHAR_MESSAGE))
                    {
                        String receiver=mess.getReceiver();
                        mess.setSendTime(new java.util.Date());//时间设置
                        //保存聊天信息在表中

                        DBUtil.saveMessage(sender,receiver,mess.getChatContent());



                        System.out.println(mess.getSender()+"对"+mess.getReceiver()+"说："+mess.getChatContent());
                        //服务器端打印聊天信息
                        //转发聊天信息到客户端并显示
                        //Hashmap类保存用户名和对应Socket对象
                        //此处receiverSocket 可能为空
                        Socket receiverSocket=(Socket) chatServer.hmSocket.get(receiver);
                        System.out.println("接收者名字"+receiver);


                        ObjectOutputStream oos=new ObjectOutputStream(receiverSocket.getOutputStream());
                        oos.writeObject(mess);


                    }
                }



            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }

        }
    public void sendMessage(Socket s,Message mess)
    {
        ObjectOutputStream oos;
        try{
            oos=new ObjectOutputStream(s.getOutputStream());
            oos.writeObject(mess);
        }catch (IOException e)
        {
            e.printStackTrace();
        }
    }


}
