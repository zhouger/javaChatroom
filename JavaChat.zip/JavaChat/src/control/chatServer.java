package control;

import DAO.DBUtil;
import model.Message;
import model.User;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class chatServer {

    public static HashMap hmSocket=new HashMap<String,Socket>();//存对象


    public chatServer()
    {
        ServerSocket ss;
        try {
            ss=new ServerSocket(3456);
            System.out.println("服务器启动,监听3456端口...");
            while (true) {
                    Socket s = ss.accept();//等待客户端连接，程序阻塞
                    System.out.println("建立连接成功" + s);




                    InputStream is = s.getInputStream();
                    ObjectInputStream ois = new ObjectInputStream(is);
                    User user = (User) ois.readObject();//转换成User对象
                    String userName=user.getUsername();
                    String password = user.getPassword();
                    System.out.println("用户名：" + userName);
                    System.out.println("密码：" + password);

                    //服务器接收到user类型
                    String userType=user.getUserTypr();
                    Message mess = new Message();

                    if(userType.equals(User.USER_REGISTER))
                    {
                        //服务器利用不同消息类型进行操作
                        if(DBUtil.seekUser(userName))//同名不能操作
                        {
                            mess.setMessageType(Message.USER_REGISTER_FAILURE);
                        }else {
                            DBUtil.instertIntoUser(userName,password);
                            mess.setMessageType(Message.USER_REGISTER_SUCCESS);
                        }
                        ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                        oos.writeObject(mess);//写入客户端
                        s.close();//关闭资源

                    }



                    if(userType.equals(User.USER_LOGIN_VALIATE))
                    {



                        //调用DBUtil中的方法实现登录验证
                        boolean loginSuccess=DBUtil.loginValidate(userName,password);


                        //登录验证,客户端获得服务器端验证结果

                        //如果登录成功
                        if(loginSuccess){
                            //访问数据库表,更新好友列表
                            String allFriend=DBUtil.seekAllFriend(userName);
                            mess.setChatContent(allFriend);//发送所有朋友名单

                            //把好友名字发送回客户端


                            mess.setMessageType(Message.LOGIN_VALIDATE_SUCCESS);
                            //服务器需要对多个客户端服务 接受并转发消息,为登录成功的用户创建一个线程
                            new ServerReceiverThread(s).start();
                            hmSocket.put(userName,s);//保存用户名字+对象



                        } else {
                            mess.setMessageType(Message.LOGIN_VALIDATE_FAILURE);
                        }
                        ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                        oos.writeObject(mess);//写入客户端

                        //注意：不要关闭s资源
                    }

            }


        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
