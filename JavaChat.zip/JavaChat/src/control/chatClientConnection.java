package control;


import model.Message;
import model.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class chatClientConnection {
    //修改s属性，传入FriendChat类

   public static Socket s;
    public chatClientConnection() {

        try {
            s=new Socket("localhost",3456);
            System.out.println("与服务器端连接");
        }
        catch (UnknownHostException e)
        {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

       public boolean registerUser(User user)
       {
           boolean registerSuccess=false;
           OutputStream os;
           Message mess=null;
           try{
               os=s.getOutputStream();
               ObjectOutputStream oss=new ObjectOutputStream(os);
               oss.writeObject(user);

               //接受来自server端的消息
               ObjectInputStream ois=new ObjectInputStream(s.getInputStream());
               mess=(Message)ois.readObject();
               if(mess.getMessageType().equals(Message.USER_REGISTER_SUCCESS))
               {
                   registerSuccess=true;
                   s.close();

               }


           }catch(IOException | ClassNotFoundException e){
               e.printStackTrace();
           }

           return registerSuccess;
       }




    public  boolean loginValidate(User user)
    {
        boolean logiinValidate=false;
        OutputStream os;
        Message mess=null;
        try{
            os=s.getOutputStream();
            ObjectOutputStream oss=new ObjectOutputStream(os);
            oss.writeObject(user);

            //接受来自server端的消息
            ObjectInputStream ois=new ObjectInputStream(s.getInputStream());
             mess=(Message)ois.readObject();
             if(mess.getMessageType().equals(Message.LOGIN_VALIDATE_SUCCESS))
             {
                 logiinValidate=true;
                 new ClientReceiverThread(s).start();

             }


        }catch(IOException | ClassNotFoundException e){
            e.printStackTrace();
    }

        return logiinValidate;
    }



    public  Message loginValidate1(User user)
    {
        OutputStream os;
        Message mess=null;
        try{
            os=s.getOutputStream();
            ObjectOutputStream oss=new ObjectOutputStream(os);
            oss.writeObject(user);
            //接受来自server端的消息
            ObjectInputStream ois=new ObjectInputStream(s.getInputStream());
            mess=(Message)ois.readObject();
            if(mess.getMessageType().equals(Message.LOGIN_VALIDATE_SUCCESS))
            {//启动线程
                new ClientReceiverThread(s).start();
            }
        }catch(IOException | ClassNotFoundException e){
            e.printStackTrace();
        }

        return mess;
    }


}
