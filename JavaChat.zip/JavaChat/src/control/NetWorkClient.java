package control;

import model.User;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class NetWorkClient {
    public static void main(String[] args) {

        try {
            Socket s=new Socket("localhost",3456);
            System.out.println("与服务器端连接");



            User user=new User();
            user.setUsername("zhouger");
            user.setPassword("032611");
            //把user发送到服务器端
             OutputStream os= s.getOutputStream();//发送到服务器
             ObjectOutputStream oos = new ObjectOutputStream(os);//节点流封装为处理流
             oos.writeObject(user);

             s.close();//关闭对象资源
        }catch (UnknownHostException e)
        {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
