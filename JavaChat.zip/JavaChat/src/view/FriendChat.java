package view;

import DAO.DB_Mail;
import control.chatClientConnection;
import model.Message;

import javax.swing.*;
import javax.xml.bind.SchemaOutputResolver;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;

public class FriendChat extends JFrame implements ActionListener, KeyListener,MouseListener {


        //定义元素
    JScrollPane jScrollPane;//滚动条
    JTextArea jArea;//多行文本框
    static JTextPane jTextPane;//文本图片混合
    JTextField jTextField;//文本字段
    JButton jButton;
    JPanel jPanel;//面板
    String sender;
    String receiver;
    JButton emoij;
    JButton file;
    JButton mail;
    JButton messBack;
    JButton shape;
    int emoNum;



    public FriendChat(String sender,String receiver) {
        this.sender=sender;
        this.receiver=receiver;
        jArea=new JTextArea();
        jArea.setFont(new Font("行楷",Font.BOLD,15));





        jTextPane=new JTextPane();

        jTextPane.insertIcon(new ImageIcon("picture/qqdefaultface/4.gif"));//jTextPanel面板

        jScrollPane=new JScrollPane(jArea);//传入多行文本为参数
        jScrollPane.add(jTextPane);//加入图文文本参数
        this.add(jScrollPane,"Center");

        jTextField=new JTextField(15);
        jTextField.addKeyListener(this);//添加文本框绑定回车发送
        jTextField.setFont(new Font("行楷",Font.PLAIN,15));
        jButton=new JButton("发送");
        jButton.addActionListener(this);//按钮事件添加监听器
        jButton.addMouseListener(this);
        jButton.setBackground(Color.white);


        emoij=new JButton("表情发送");
        emoij.addActionListener(this);
        emoij.addMouseListener(this);
        emoij.setBackground(Color.white);

        file=new JButton("文件发送");
        file.addActionListener(this);
        file.addMouseListener(this);
        file.setBackground(Color.white);

        mail=new JButton("邮件发送");
        mail.addActionListener(this);
        mail.addMouseListener(this);
        mail.setBackground(Color.white);

        messBack=new JButton("撤回");
        messBack.addActionListener(this);
        messBack.addMouseListener(this);
        messBack.setBackground(Color.white);

        shape=new JButton("抖动");
        shape.addActionListener(this);
        shape.addMouseListener(this);
        shape.setBackground(Color.white);


        jTextPane.setFont(new Font("行楷",Font.PLAIN,20));


        jPanel=new JPanel();
        jPanel.add(jTextField);//添加文本框到面板

        jPanel.add(jButton);//添加发送按钮
        jPanel.add(emoij);
        jPanel.add(file);
        jPanel.add(mail);
        jPanel.add(jTextPane);
        jPanel.add(messBack);
        this.add(jPanel,"South");
        this.setSize(700,400);
        this.setTitle(receiver);
        this.setLocationRelativeTo(null);//窗口显示到中间
        this.setVisible(true);//可显示
        this.setIconImage(new ImageIcon("picture/joker.png").getImage());


        jArea.setEditable(false);
        jTextPane.setEditable(false);

        jArea.add(jTextPane);
        jTextPane.setBackground(Color.GRAY);
        jArea.setForeground(Color.PINK);
        jPanel.setBackground(Color.GRAY);//底部
        jArea.setBackground(Color.GRAY);//背景
        jArea.setText("系统消息：欢迎来到聊天室！"+"\n\r"+"您正在与"+receiver+"聊天"+"\n\r");




    }



    public static void main(String[] args) {
        //FriendChat friendChat=new FriendChat();
    }


    public void Shape()
    {
        int num = 100;// 抖动次数
        Point point = jArea.getLocation();// 窗体位置
        for (int i = 100; i > 0; i--) {

            for (int j = num; j > 0; j--) {
                point.y += i;
                jArea.setLocation(point);
                point.x += i;
                jArea.setLocation(point);
                point.y -= i;
                jArea.setLocation(point);
                point.x -= i;
                jArea.setLocation(point);

            }
        }

    }
    public String Emo(int index)
    {
        String emo;
        ArrayList<String> ss=new ArrayList<>();
        Collections.addAll(ss, "🙂","😅","😍","😋","😎","🤣","🤨","😅","😓","😭","😡");
        if(index>ss.size())
        {
            emo="🤡";
        }else
        {
            emo=ss.get(index);
        }
        return emo;
    }

    public  void back()
    {
        jArea.setText("该消息已撤回"+"\r\n");
    }
    public  void append(Message mess)//显示消息方法
    {
        //显示时间


        jArea.append(mess.getSendTime().toLocaleString()+"\r\n"+mess.getSender()+"对"+mess.getReceiver()+"说:"+mess.getChatContent()+"\n\r");



    }

    public void SendMessage()
        {

        System.out.println("发送了信息");


        //发送聊天消息到服务器并创建message对象
        Message mess=new Message();
        mess.setSender(sender);
        mess.setReceiver(receiver);
        String chatContent=jTextField.getText();
        mess.setChatContent(chatContent);
        mess.setMessageType(Message.COMMON_CHAR_MESSAGE);


            jArea.append(sender+"对"+receiver+"说:"+jTextField.getText()+"\n\r");//文本框发送到文本区域


        //客户端发送到服务器
        try {
            ObjectOutputStream oos=new ObjectOutputStream(chatClientConnection.s.getOutputStream());//输出到服务器
            oos.writeObject(mess);//信息写入mess
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }

    }




    @Override
    public void actionPerformed(ActionEvent e) {


        if(e.getSource()==shape)
        {
            Shape();
            System.out.println("抖动");
        }
        if(e.getSource()==messBack)
        {
            back();
        }

        if(e.getSource()==emoij)
        {
            view.emoij emo=new emoij();
        }

        if(e.getSource()==file)//文件选择框
        {

            this.setVisible(true);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JFileChooser jfc=new JFileChooser();
            jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES );
            jfc.showDialog(new JLabel(), "选择");
            File file=jfc.getSelectedFile();
            String path = file.getAbsolutePath();
            if(file.isDirectory()){
                System.out.println("文件夹:"+path);
            }else if(file.isFile()){
                System.out.println("文件:"+path);
            }

            System.out.println(jfc.getSelectedFile().getName());

//            fileChooser.setCurrentDirectory(new File("C:/Users/Samven/Desktop"));
//            // 添加可用的文件过滤器（FileNameExtensionFilter 的第一个参数是描述, 后面是需要过滤的文件扩展名）
////        fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("(txt)", "txt"));
//            // 设置默认使用的文件过滤器（FileNameExtensionFilter 的第一个参数是描述, 后面是需要过滤的文件扩展名 可变参数）
//            fileChooser.setFileFilter(new FileNameExtensionFilter("(txt)", "txt"));
//            // 打开文件选择框（线程将被堵塞，知道选择框被关闭）
//            int result = fileChooser.showOpenDialog(parent);  // 对话框将会尽量显示在靠近 parent 的中心
//            // 点击确定
//            if(result == JFileChooser.APPROVE_OPTION) {
//                // 获取路径




        }

        if(e.getSource()==mail)
        {

            DB_Mail db_mail=new DB_Mail("发送邮件给好友");

            //DBUtil.saveEamil(textField.getText(), textField1.getText(),textField3.getText());
        }


        if(e.getSource()==jButton)
        {
            SendMessage();
            jTextField.setText("");

        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override//键盘按下
    public void keyPressed(KeyEvent e) {
            if(e.getKeyCode()==KeyEvent.VK_ENTER)
            {
                SendMessage();
                jTextField.setText("");
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

        if(e.getSource()==jButton)
        {
            jButton.setBackground(Color.green);
        }

        if(e.getSource()==emoij)
        {
            emoij.setBackground(Color.green);
        }

        if(e.getSource()==file)
        {
            file.setBackground(Color.green);
        }

        if(e.getSource()==mail)
        {
            mail.setBackground(Color.green);
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {

        if(e.getSource()==jButton)
        {
            jButton.setBackground(Color.white);
        }

        if(e.getSource()==emoij)
        {
            emoij.setBackground(Color.white);
        }

        if(e.getSource()==file)
        {
            file.setBackground(Color.white);
        }

        if(e.getSource()==mail)
        {
            mail.setBackground(Color.white);
        }
    }
}
