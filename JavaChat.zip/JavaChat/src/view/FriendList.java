package view;

import control.chatClientConnection;
import model.Message;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.HashMap;

import static control.chatClientConnection.s;

public class FriendList extends JFrame implements ActionListener, MouseListener {
    //创建Hashmap  保存Friendchat对象
    public static HashMap hmFriendChat=new HashMap<String,FriendChat>();



    //定义卡片面板1
    JPanel myFriendPanel;
    JButton addFriendJButton;
    JButton myFriendJButton;
    JPanel addFriendJPenel;


    //中部滚动条
    JScrollPane jScrollPane;//滚动条
    JPanel myFriendListJPanel;
    final int friendCount=50;
    JLabel myFriendJLabel[]=new JLabel[friendCount];//定义对象数组

    //定义南部组件
    JButton strangerJButton1;//陌生人卡片
    JButton blackListJButton;
    JPanel stranger_blackList_JPanel;



    //定义卡片面板2
    JPanel myStrangerPanel;
    JPanel friend_Stringer_Panel;
    JButton myFriendJButton1;
    JButton strangerJButton;

    //定义中部组件
    JScrollPane strangerJScrollPane;
    JPanel strangerListPanel;
    final int STRANGERCOUNT=20;
    JLabel strangerJLabel[]=new JLabel[STRANGERCOUNT];



    //定义南部组件
    JButton blackListJButton1;




    CardLayout cardLayout;//布局管理器
    String userName;//定义用户名

    //public FriendList()
    //public FriendList(String userName)
    public FriendList(String userName,String allFriend)
    {
        this.userName=userName;//给外部userName赋值
        //创建面板(好友卡片)
        myFriendPanel=new JPanel(new BorderLayout());//默认流式布局改边界布局
        addFriendJPenel=new JPanel(new GridLayout(2,1));//网格布局
        addFriendJButton=new JButton("添加好友");
        addFriendJButton.addActionListener(this);
        myFriendJButton=new JButton("我的好友");
        addFriendJPenel.add(addFriendJButton);
        addFriendJPenel.add(myFriendJButton);
        //添加 更新好友列表按钮

        myFriendPanel.add(addFriendJPenel,"North");


        //利用allFriend来更新好友图标
        myFriendListJPanel=new JPanel();
        updataFriendList(allFriend);


        //实现好友卡片的中部
//        myFriendListJPanel=new JPanel(new GridLayout(50,1));//网格布局管理好友图标
//        for(int i=1;i<MYFRIENDCOUNT;i++)//循环创建
//        {
//            //myFriendJLabel[i]=new JLabel(i+"号好友🤡",new ImageIcon("picture/joker.png"),JLabel.LEFT);
//            myFriendJLabel[i]=new JLabel(i+"",new ImageIcon("picture/joker.png"),JLabel.LEFT);
//            //好友图标设置为非激活状态,除用户自己之外的图标
////            if(Integer.valueOf(userName)!=i) myFriendJLabel[i].setEnabled(false);
//            myFriendJLabel[i].addMouseListener(this);//添加鼠标监听器
//            myFriendListJPanel.add(myFriendJLabel[i]);
//        }
//

        jScrollPane=new JScrollPane(myFriendListJPanel);
        myFriendPanel.add(jScrollPane,"Center");

        //实现好友卡片南部
        strangerJButton1=new JButton("陌生人");
        strangerJButton1.addActionListener(this);//添加动作监听器
        blackListJButton=new JButton("黑名单");
        stranger_blackList_JPanel=new JPanel(new GridLayout(2,1));
        stranger_blackList_JPanel.add(strangerJButton1);
        stranger_blackList_JPanel.add(blackListJButton);
        myFriendPanel.add(stranger_blackList_JPanel,"South");



        //陌生人卡片
        myStrangerPanel=new JPanel(new BorderLayout());

        friend_Stringer_Panel=new JPanel(new GridLayout(2,1)); //网格布局两行一列
        myFriendJButton1=new JButton("我的好友");
        myFriendJButton1.addActionListener(this);//添加动作监听器
        strangerJButton=new JButton("陌生人");
        friend_Stringer_Panel.add(myFriendJButton1);
        friend_Stringer_Panel.add(strangerJButton);
        myStrangerPanel.add(friend_Stringer_Panel,"North");

        //创建中部组件
        strangerListPanel=new JPanel(new GridLayout(STRANGERCOUNT,1));
        for(int i=0;i<STRANGERCOUNT;i++)
        {
            strangerJLabel[i]=new JLabel(i+"号陌生人",new ImageIcon("picture/joker2.png"),JLabel.LEFT);
            strangerListPanel.add(strangerJLabel[i]);//加入在陌生人表中
        }


        strangerJScrollPane=new JScrollPane(strangerListPanel);
        myStrangerPanel.add(strangerJScrollPane,"Center");//加入卡片中

        //创建南部组件
        blackListJButton1=new JButton("黑名单");
        myStrangerPanel.add(blackListJButton1,"South");






        cardLayout=new CardLayout();//卡片布局管理
        this.setLayout(cardLayout);
        this.add(myFriendPanel,"1");
        this.add(myStrangerPanel,"2");
        //cardLayout.show(this.getContentPane(),"1");//展示界面设置“我的好友界面”
        cardLayout.show(this.getContentPane(),"2");//展示界面设置“陌生人界面”


        this.setSize(450,450);
        this.setTitle(userName+"的好友列表");
        this.setIconImage(new ImageIcon("picture/joker.png").getImage());//修改左上图标
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        myFriendPanel.setBackground(Color.GRAY);
        myStrangerPanel.setBackground(Color.GRAY);



    }



    public void updataFriendList(String allFriend) {
        myFriendListJPanel.removeAll();//移除后添加
        String friendName[]= allFriend.split(" ");
        int friendCount= friendName.length;
        myFriendListJPanel.setLayout(new GridLayout(friendName.length,1));//网格布局管理好友图标
        for(int i=1;i<friendCount;i++)//循环创建
        {
//            if(Integer.valueOf(userName)!=i) myFriendJLabel[i].setEnabled(false);

            myFriendJLabel[i]=new JLabel(friendName[i],new ImageIcon("picture/joker.png"),JLabel.LEFT);
            myFriendJLabel[i].addMouseListener(this);//添加鼠标监听器
            myFriendListJPanel.add(myFriendJLabel[i]);
        }
        myFriendListJPanel.revalidate();//重新验证更新
    }


    public static void main(String[] args) {
       // FriendList friendList=new FriendList();
    }

    //新上线好友图标激活
    public void setEnabledNewOnLineFriendIcno(String newOnLineFriend)
    {
        //myFriendJLabel[Integer.valueOf(newOnLineFriend.trim())].setEnabled(true);

        /*中文ID转换为Integer类型出错，用户名为中文时会报错，注意设置编码方式utf8,     该错误为：String 不包含可分析整数
          在把 String 转 int 时，当 String 有空格 会报这个错误
          作者仍无法解决这个问题，2021/10/29日
          用户名为中文时*/

        /*错误信息：Exception in thread "Thread-2" java.lang.NumberFormatException: For input string: "洲"
	at java.lang.NumberFormatException.forInputString(NumberFormatException.java:65)
	at java.lang.Integer.parseInt(Integer.java:580)
	at java.lang.Integer.valueOf(Integer.java:766)
	at view.FriendList.setEnabledNewOnLineFriendIcno(FriendList.java:190)
	at control.ClientReceiverThread.run(ClientReceiverThread.java:67)*/

        //2021/11/7
        //myFriendJLabel[Integer.valueOf(newOnLineFriend.trim())].setEnabled(true);

        /*作者尝试使用.trim()方法去掉字符串的空格，失败
        错误信息：Exception in thread "Thread-2" java.lang.NumberFormatException: For input string: "zhouger"
	at java.lang.NumberFormatException.forInputString(NumberFormatException.java:65)
	at java.lang.Integer.parseInt(Integer.java:580)
	at java.lang.Integer.valueOf(Integer.java:766)
	at view.FriendList.setEnabledNewOnLineFriendIcno(FriendList.java:202)
	at control.ClientReceiverThread.run(ClientReceiverThread.java:67)
    */
        //输入为英文id时报错,2021/11/4作者任然无法解决该问题

    }



    public void setEnabledOnLineFriendIcno(String onlineFriend)
    {
       String friendName[]= onlineFriend.split(" ");//在线好友名字放入数组
        int count=friendName.length;//好友数
        for(int i=1;i<count;i++)
        {
            myFriendJLabel[Integer.valueOf(friendName[i].trim())].setEnabled(true);//激活
        }
    }




    @Override//实现动作监听器
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==strangerJButton1)
        {
            cardLayout.show(this.getContentPane(),"2");//展示界面设置“陌生人界面”
        }

        if(e.getSource()==myFriendJButton1)
        {
            cardLayout.show(this.getContentPane(),"1");//展示界面设置“陌生人界面”
        }

        if(e.getSource()==addFriendJButton)
        {//输入用户名字发送到服务器
           String newFriendName= JOptionPane.showInputDialog("请输入好友名字");
           Message mess=new Message();
           mess.setSender(userName);
           mess.setReceiver("Server");
           mess.setChatContent(newFriendName);
           mess.setMessageType(Message.ADD_NEW_FRIEND);
            OutputStream os;
            try {
                os = chatClientConnection.s.getOutputStream();
                ObjectOutputStream oss=new ObjectOutputStream(os);
                oss.writeObject(mess);//服务端输出写入mess
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }

        }
    }

    @Override//鼠标点击事件监听
    public void mouseClicked(MouseEvent e) {

        if(e.getClickCount()==1)//鼠标单机弹出界面
        {
            JLabel jLabel=(JLabel)e.getSource();
            String receiver=jLabel.getText();
//            new FriendChat(userName,receiver);
            FriendChat friendChat= new FriendChat(userName,receiver);//保存信息对象
             hmFriendChat.put(userName+"to"+receiver,friendChat);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        JLabel jLabel=(JLabel) e.getSource();
        jLabel.setForeground(Color.red);//鼠标悬停颜色
    }

    @Override
    public void mouseExited(MouseEvent e) {

        JLabel jLabel=(JLabel) e.getSource();
        jLabel.setForeground(Color.blue);//悬停离开后颜色
    }
}
