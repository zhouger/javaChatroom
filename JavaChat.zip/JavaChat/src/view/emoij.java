package view;

import control.chatClientConnection;
import model.Message;
import model.MessageType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;

import static view.FriendChat.jTextPane;

public class emoij extends JFrame implements MouseListener {

    public int i=0;
    public String emoMess;
    public String mes;

    public int index;

    public int getIndex(int index) {
        return index;
    }

    public String getMes() {//输出到服务端执行，按钮编号
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getEmoMess() {//获得按钮信息,输出到服务端打印
        return emoMess;
    }

    public void setEmoMess(String emoMess) {
        this.emoMess = emoMess;
    }

    public emoij()
    {
        button();
    }

    //存取表情方法  参数为表情序号


    public void Emoij()
    {
        jTextPane.insertIcon(new ImageIcon("picture/qqdefaultface/"+mes+".gif"));//jTextPanel面板

    }

    public String Emo(int index)
    {
        String emo;
        ArrayList<String> ss=new ArrayList<>();
        Collections.addAll(ss, "🙂","😅","😍","😋","😎","🤣","🤨","😅","😓","😭","😡");
        if(index>ss.size())
        {
            emo="🤡";
        }else
        {
            emo=ss.get(index);
        }
        return emo;
    }

    public void button()
    {
        JFrame jf=new JFrame("表情发送");
        jf.setSize(600,600);
        jf.setLocationRelativeTo(null);
        JPanel emoijJP=new JPanel( );
        jf.setVisible(true);
        jf.setContentPane(emoijJP);
        for(i=0;i<105;i++)
        {

            ImageIcon path=new ImageIcon("picture/qqdefaultface/"+i+".gif");
            JButton bname=new JButton(""+i);
            bname.setFont(new Font("宋体",1,0));//隐藏图片信息
            emoijJP.add(bname);
            bname.setIcon(path);
            bname.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if(e.getClickCount()==1)
                    {

                        mes=bname.getText();
                        index= Integer.parseInt(mes);//获得表情序号
                        emoMess="用户按下了："+mes+"号按钮";
                        System.out.println(getEmoMess());
                        Message mess=new Message();
                        mess.setMes(mes);
                        mess.setMessageType(Message.PICTURE_CHAR_MESSAGE);
                        //发送表情信息到服务器,输入输出流
                       try{
                           ObjectOutputStream oos=new ObjectOutputStream(chatClientConnection.s.getOutputStream());
                           oos.writeObject(mess);
                       }catch (IOException e1)
                       {
                           e1.printStackTrace();
                       }



                        Emoij();//插入表情图片
                        jTextPane.setLocation(100,200);//插入图片位置
                        //添加到text框内
//                       FriendChat.jTextField.setText(FriendChat.jTextField.getText()+Emo(index));

                    }
                }

                @Override
                public void mousePressed(MouseEvent e) {

                }

                @Override
                public void mouseReleased(MouseEvent e) {

                }

                @Override
                public void mouseEntered(MouseEvent e) {

                }

                @Override
                public void mouseExited(MouseEvent e) {

                }
            });
        }


    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
