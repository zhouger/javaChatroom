package view;

import DAO.DB_Mail;
import control.chatClientConnection;
import control.chatServer;
import model.Message;
import model.User;
import model.UserType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;

/*Anthor:zhouger
Begin:2021/10/26
Finish：2021/11/3
作者：韶关学院 信息工程学院 数据科学与大数据技术01班 陈鋆洲
版权所有，盗版必究！
*/
public class ClientLogin extends JFrame implements ActionListener {


    public static  HashMap hmFriendList=new HashMap<String,FriendList>();//保存用户名和对应好友列表




    JLabel jLabel;
    JButton jButton_Login;//登录按钮
    JButton jButton_Register;//注册按钮
    JButton jButton_Cancel;//取消按钮
    JButton jButton_Email;
    JPanel jPanel_Action;

    JTabbedPane jTabbedPane;
    JPanel jPanel_QqNumber;
    JPanel jPanel_Phone;
    JPanel jPanel_Email;


    //定义组件
    JLabel jLabel_QqNumber;
    JLabel jLabel_Password;
    JLabel jLabel_Phone;
    JLabel jLabel_number;
    JLabel jLabel3;//忘记密码
    JLabel jLabel4;//申请密码保护
    JLabel jLabel_Email;//电子邮箱
    JLabel jLabel_Emailpassword;//电子邮箱密码

    JTextField jTextField;//文本
    JTextField jPasswordField;//文本
    JButton jButton_Clear;//清楚按钮
    JCheckBox jCheckBox1;//复选框
    JCheckBox jCheckBox2;//同上
    JTextField jTextFieldPhone;//文本电话
    JTextField jField1;//文本验证码
    JTextField jTextField2;//文本电子邮箱
    JTextField jField2;//文本电子邮箱密码







    public ClientLogin()
    {

        jLabel=new JLabel(new ImageIcon("picture/background.png"));//获得背景
        this.add(jLabel,"North");//背景图片布局调整

        //中部添加组件
        jTabbedPane=new JTabbedPane();
        jPanel_QqNumber=new JPanel(new GridLayout(3,3));//网格布局3×3
        jLabel_QqNumber=new JLabel("用户名",JLabel.CENTER);
        jLabel_Password=new JLabel("密码",JLabel.CENTER);
        jLabel3=new JLabel("忘记密码",JLabel.CENTER);
        jLabel3.setForeground(Color.pink);
        jLabel4=new JLabel("申请密码保护",JLabel.CENTER);
        jTextField=new JTextField();//文本框
        jTextField.setPreferredSize(new Dimension (10,10));
        jPasswordField=new JTextField();//密码框
        jPasswordField.setPreferredSize(new Dimension (10,10));
        jButton_Clear=new JButton(new ImageIcon("picture/clear_password.png"));//清除密码图片
        jButton_Clear.setPreferredSize(new Dimension(5,5));
        jCheckBox1=new JCheckBox("隐身登录");
        jCheckBox2=new JCheckBox("记住密码");

        //添加组件到QQ号码面板
        jPanel_QqNumber.add(jLabel_QqNumber);
        jPanel_QqNumber.add(jTextField);
        jPanel_QqNumber.add(jButton_Clear);
        jButton_Clear.addActionListener(this);//清空按钮
        jPanel_QqNumber.add(jLabel_Password);
        jPanel_QqNumber.add(jPasswordField);
        jPanel_QqNumber.add(jLabel3);
        jPanel_QqNumber.add(jCheckBox1);
        jPanel_QqNumber.add(jCheckBox2);
        jPanel_QqNumber.add(jLabel4);




        //电话面板
        jPanel_Phone=new JPanel(new GridLayout(3,3));//网格布局3×3
        jLabel_Phone=new JLabel("电话号码",JLabel.CENTER);
        jLabel_number=new JLabel("验证码",JLabel.CENTER);
        jTextFieldPhone=new JTextField();
        jField1=new JTextField();

        jPanel_Phone.add(jLabel_Phone);
        jPanel_Phone.add(jTextFieldPhone);
        jPanel_Phone.add(jLabel_number);
        jPanel_Phone.add(jField1);


        //邮箱面板
        jPanel_Email=new JPanel(new GridLayout(3,3));
        jLabel_Email=new JLabel("电子邮箱",JLabel.CENTER);
        jLabel_Emailpassword=new JLabel("邮箱密码",JLabel.CENTER);
        jTextField2=new JTextField();
        jField2=new JTextField();
        jPanel_Email.add(jLabel_Email);
        jPanel_Email.add(jTextField2);
        jPanel_Email.add(jLabel_Emailpassword);
        jPanel_Email.add(jField2);




        jTabbedPane.add(jPanel_QqNumber,"Chat账号");
        jTabbedPane.add(jPanel_Phone,"手机号码");
        jTabbedPane.add(jPanel_Email,"电子邮箱");
        this.add(jTabbedPane,"Center");



        jButton_Login =new JButton(new ImageIcon("picture/login.png"));//按钮图片获取
        jButton_Login.addActionListener(this);//添加监听器

        jButton_Register =new JButton(new ImageIcon("picture/smuit.png"));
        jButton_Register.addActionListener(this);

        jButton_Cancel =new JButton(new ImageIcon("picture/esc.png"));
        jButton_Cancel.addActionListener(this);


        jButton_Email=new JButton(new ImageIcon("picture/mail.png"));
        jButton_Email.addActionListener(this);


        jPanel_Action=new JPanel();
        jPanel_Action.add(jButton_Login);//加入动作按钮
        jPanel_Action.add(jButton_Register);
        jPanel_Action.add(jButton_Cancel);
        jPanel_Action.add(jButton_Email);




        this.add(jPanel_Action,"South");


        this.setSize(600,500);//图片大小调整
        this.setTitle("南桐♂交流");
        this.setIconImage(new ImageIcon("picture/joker.png").getImage());//修改左上图标
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//关闭程序方式

        this.setVisible(true);
        this.setLocationRelativeTo(null);//窗口显示到中间

        jPanel_Action.setBackground(Color.GRAY);

    }
    public static void main(String[] args) {
    ClientLogin clientLogin=new ClientLogin();
    }

    public void sendMessage(Socket s,Message mess)
    {
        OutputStream os;
        try {
            os = s.getOutputStream();
            ObjectOutputStream oss=new ObjectOutputStream(os);
            oss.writeObject(mess);//服务端输出写入mess
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }



    @Override//实现监听器方法
    public void actionPerformed(ActionEvent e) {



        if(e.getSource()==jButton_Email)
        {
            DB_Mail db_mail=new DB_Mail("与洲哥联系，给作者提建议(●'◡'●)");

            JOptionPane.showMessageDialog(null,"作者邮箱2112581537@qq.com");



        }



        if(e.getSource()==jButton_Cancel)
        {
            Suppot suppot=new Suppot();

        }




        if(e.getSource()==jButton_Register)
        {
            String userName=jTextField.getText().trim();
            String password=new String(jPasswordField.getText());//拿不到getPassword()方法
            User user=new User();
            user.setUsername(userName);
            user.setPassword(password);

            user.setUserTypr(User.USER_REGISTER);


            //注册方法
            boolean registerSuccess=new chatClientConnection().registerUser(user);
            if(registerSuccess)
            {
                JOptionPane.showMessageDialog(this,userName+"注册成功！");
            }else {
                JOptionPane.showMessageDialog(this,userName+"有同名用户，注册失败！");
            }

        }

        if(e.getSource()==jButton_Clear)//清空事件
        {
            jTextField.setText("");
        }


        if(e.getSource()==jButton_Login)//登录事件
        {
            String userName=jTextField.getText();
            String password=new String(jPasswordField.getText());//拿不到getPassword()方法
            User user=new User();
            user.setUsername(userName);
            user.setPassword(password);

            user.setUserTypr(UserType.USER_LOGIN_VALIATE);
            Message mess=new chatClientConnection().loginValidate1(user);
            if(mess.getMessageType().equals(Message.LOGIN_VALIDATE_SUCCESS))
            {
                String allFriend= mess.getChatContent();//取出好友名字
                FriendList friendList=new FriendList(userName,allFriend);
                ClientLogin.hmFriendList.put(userName,friendList);

                //登录成功后向服务器发送请求信息，请求从服务器端发送
                mess=new Message();
                mess.setSender(userName);
                mess.setReceiver("Server");
                mess.setMessageType(Message.REQUEST_ONLINE_FRIEND);
                sendMessage(chatClientConnection.s,mess);
                //this.dispose();登录后登陆界面消失,在idea中不能多开窗口，所以为了测试方便，注释该代码

                mess.setMessageType(Message.NEW_ONLINE_FRIEND_TO_SERVER);
                sendMessage(chatClientConnection.s,mess);
                jTextField.setText("");
                jPasswordField.setText("");

            }else{
                JOptionPane.showMessageDialog(this,"密码错误！请重新输入");
                //密码输入错误弹窗
                jPasswordField.setText("");
            }


//            new FriendList(userName);//弹出好友列表
        }

    }
}
