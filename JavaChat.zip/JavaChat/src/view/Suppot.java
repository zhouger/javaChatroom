package view;

import chatserver.StartServer;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Suppot extends JFrame implements ActionListener {

    JButton startServerJButton;
    JButton stopServerJButton;
    JPanel jPanel;

    public Suppot() {
        JLabel suppot=new JLabel(new ImageIcon("picture/suppot.jpg"));

        this.add(suppot,"Center");//加入JFram组件

        jPanel=new JPanel();

        this.setSize(1000,1000);
        this.setLocationRelativeTo(null);//窗口初始位置
        this.setVisible(true);//可视化
        this.setIconImage(new ImageIcon("picture/joker.png").getImage());//修改左上图标
        this.setTitle("谢谢支持");

    }
    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
