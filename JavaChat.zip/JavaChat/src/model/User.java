package model;

import java.io.Serializable;

public class User implements Serializable,UserType{//实现该接口使对象可以被序列化
    String username;
    String password;

    String userTypr;

    public String getUserTypr() {
        return userTypr;
    }

    public void setUserTypr(String userTypr) {
        this.userTypr = userTypr;
    }

    public String getUsername() {
        return username;
    }

    public User() {
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



}
