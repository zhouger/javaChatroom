package model;

import javax.xml.crypto.Data;
import java.io.Serializable;

public class Email implements Serializable,UserType{

    Data sendtime;
    String receiver_mail;
    String MailTitle;
    String MailMessage;

    public Data getSendtime() {
        return sendtime;
    }

    public void setSendtime(Data sendtime) {
        this.sendtime = sendtime;
    }

    public String getReceiver_mail() {
        return receiver_mail;
    }

    public void setReceiver_mail(String receiver_mail) {
        this.receiver_mail = receiver_mail;
    }

    public String getMailTitle() {
        return MailTitle;
    }

    public void setMailTitle(String MailTitle) {
        this.MailTitle = MailTitle;
    }

    public String getMailMessage() {
        return MailMessage;
    }

    public void setMailMessage(String MailMessage) {
        this.MailMessage = MailMessage;
    }
}
