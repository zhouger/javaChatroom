package model;

public interface MessageType {//常量验证信息定义
    String LOGIN_VALIDATE_SUCCESS="1";
    String LOGIN_VALIDATE_FAILURE="2";
    String COMMON_CHAR_MESSAGE="3";//定义新的消息类型
    String PICTURE_CHAR_MESSAGE="14";
    String FILE_CHAR_MESSAGE="15";
    String ROLL_BACK_MESSAAAGE="16";


    //请求类型
    String REQUEST_ONLINE_FRIEND="4";
    String RESPON_ONLINE_FRIEND="5";

    //激活图标的消息类型
    String NEW_ONLINE_FRIEND_TO_SERVER="6";
    String NEW_ONLINE_FRIEND="7";

    //注册消息类型
    String USER_REGISTER_SUCCESS="8";
    String USER_REGISTER_FAILURE="9";

    //添加好友消息类型
    String ADD_NEW_FRIEND="10";
    String ADD_NEW_FRIEND_SUCCESS="11";
    String ADD_NEW_FRIEND_FAILURE_NO_USER="12";
    String ADD_NEW_FRIEND_FAILURE_ALREADY_FRIEND="13";

}
