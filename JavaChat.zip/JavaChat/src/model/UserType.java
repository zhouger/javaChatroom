package model;

public interface UserType {
    String USER_LOGIN_VALIATE="1";
    String USER_REGISTER="2";
}
