package model;



import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable,MessageType {
    String messageType;
    //发送聊天信息到服务器,定义三个成员变量
    String sender;
    String receiver;
    String chatContent;

    Date sendTime;
    //发送聊天时间，与信息

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }



    //添加新的属性名
    String onLineFriend;

    public String getOnLineFriend() {
        return onLineFriend;
    }

    public void setOnLineFriend(String onLineFriend) {
        this.onLineFriend = onLineFriend;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getChatContent() {
        return chatContent;
    }

    public void setChatContent(String chatContent) {
        this.chatContent = chatContent;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }



    //表情发送信息
    public String emoMess;
    public String mes;

    public String getMes() {//输出到服务端执行，按钮编号
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getEmoMess() {//获得按钮信息,输出到服务端打印
        return emoMess;
    }

    public void setEmoMess(String emoMess) {
        this.emoMess = emoMess;
    }
}
